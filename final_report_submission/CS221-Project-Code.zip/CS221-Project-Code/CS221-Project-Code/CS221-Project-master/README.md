# CS221-Project

  

DATA: open AI gym, Atari-EnduroV0

random player_edges:
    
	player_Qw_feat.py - Runs a simulation (currently hardcoded for 5 simulations
                       
	 of 1000 maxiterations) of QLearning function approximation.
                        
	It uses the feature extraction of detecting cars
 provided by edge_det.py (in random player_edges).
                        
	(AS SEEN IN THE REPORT)
	COMMAND: python player_Qw_feat.py
	

	

cartpole.py - Initial attempts to run the game and gain a better understanding of
 the environment



10digits:
    
	nums_value.py - testing code to see if we can find the current car position
 in the race correctly from 
	the observation.



carClass:
    
	player_Qw.py
: test simulation on QL with identity feature extractor
        player.py: test to use value iteration 

carClassOneGame:
    
	player.py

: another test on value iteration

qlearning:
 
   
	qlearning.py: use QL approximated with updating exploring and learning rates. 



random player:
    
		ocr.py - testing Google Tesseract to extract car position in the race.
    
		test.py - getting car position accurately using pixel positions.


ValuePlayer:
    
		test.py - code to run value iteration which didnt do well as explained in the report
