Data:

used open AI gym, Atari-EnduroV0